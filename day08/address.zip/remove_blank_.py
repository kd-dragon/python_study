
f1 = open("address.txt", 'r', encoding='utf-8')
data = f1.read()

print(data)
print("====================== 코딩 후 ========================== ")