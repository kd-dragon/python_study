
f1 = open("notice.txt", 'r', encoding='utf-8')
data = f1.read()

#여기 코딩해서 프린트 출력!
output = data

print(output)