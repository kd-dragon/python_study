import file_module as fm

fm.write_lines(5, "D:/test/ex01.txt")
fm.read_all("D:/test/ex01.txt")
fm.append_lines(5, "D:/test/ex01.txt")